export class Todo {
    sno: number = 0; // Initialize with a default value
    title: string = ''; // Initialize with a default value
    desc: string = ''; // Initialize with a default value
    active: boolean = true; // Initialize with a default value

    constructor() {
        // You can initialize properties further in the constructor if needed
    }
}
